#!/usr/bin/env python3
"""
周报生成器启动入口
支持打包为独立可执行文件
"""
import os
import sys
import subprocess
import webbrowser
import time
import signal
import threading

def get_resource_path(relative_path):
    """获取资源文件路径（支持打包后的路径）"""
    if hasattr(sys, '_MEIPASS'):
        # PyInstaller 打包后的临时目录
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)

def main():
    """主函数"""
    # 设置工作目录
    if hasattr(sys, '_MEIPASS'):
        os.chdir(sys._MEIPASS)
    else:
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    print("=" * 50)
    print("🚀 周报生成器启动中...")
    print("=" * 50)
    
    # 检查端口是否被占用
    import socket
    port = 8501
    max_retries = 10
    
    for i in range(max_retries):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('localhost', port))
        sock.close()
        
        if result != 0:  # 端口可用
            break
        port += 1
    
    print(f"📡 使用端口: {port}")
    
    # 设置环境变量
    env = os.environ.copy()
    env['STREAMLIT_SERVER_HEADLESS'] = 'true'
    env['STREAMLIT_SERVER_PORT'] = str(port)
    env['STREAMLIT_SERVER_ADDRESS'] = 'localhost'
    env['STREAMLIT_BROWSER_GATHERUSAGESTATS'] = 'false'
    
    # 启动 Streamlit
    try:
        process = subprocess.Popen(
            [sys.executable, '-m', 'streamlit', 'run', 'app.py',
             f'--server.port={port}',
             '--server.address=localhost',
             '--browser.gatherUsageStats=false'],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True
        )
    except Exception as e:
        print(f"❌ 启动失败: {e}")
        input("按回车键退出...")
        return
    
    # 读取输出的线程
    def read_output():
        for line in process.stdout:
            print(line, end='')
    
    output_thread = threading.Thread(target=read_output, daemon=True)
    output_thread.start()
    
    # 等待服务启动
    print("⏳ 正在启动服务...")
    time.sleep(5)
    
    # 检查服务是否成功启动
    url = f'http://localhost:{port}'
    
    # 尝试打开浏览器
    print(f"🌐 正在打开浏览器: {url}")
    try:
        webbrowser.open(url)
    except Exception as e:
        print(f"⚠️ 无法自动打开浏览器，请手动访问: {url}")
    
    print("")
    print("=" * 50)
    print("✅ 周报生成器已启动！")
    print(f"🌐 访问地址: {url}")
    print("")
    print("⚠️  请不要关闭此窗口")
    print("🛑 关闭此窗口将停止服务")
    print("=" * 50)
    print("")
    
    # 处理退出信号
    def signal_handler(sig, frame):
        print("\n🛑 正在关闭服务...")
        process.terminate()
        try:
            process.wait(timeout=5)
        except:
            process.kill()
        print("✅ 服务已停止")
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 等待进程结束
    try:
        process.wait()
    except KeyboardInterrupt:
        signal_handler(None, None)

if __name__ == '__main__':
    main()
