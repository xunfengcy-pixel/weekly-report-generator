#!/usr/bin/env python3
"""
周报生成器启动入口
支持打包为独立可执行文件
"""
import os
import sys
import subprocess
import webbrowser
import time
import signal
import threading
import socket
import urllib.request

def get_resource_path(relative_path):
    """获取资源文件路径（支持打包后的路径）"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)

def check_port_available(port):
    """检查端口是否可用"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('localhost', port))
    sock.close()
    return result != 0

def wait_for_server(url, timeout=60):
    """等待服务启动，通过访问健康检查端点"""
    start_time = time.time()
    check_url = url.replace('http://localhost', 'http://127.0.0.1')
    
    print(f"⏳ 等待服务启动: {url}")
    
    while time.time() - start_time < timeout:
        try:
            # 尝试访问 Streamlit 健康检查端点
            req = urllib.request.Request(
                f"{check_url}/_stcore/health",
                method='GET',
                headers={'User-Agent': 'Mozilla/5.0'}
            )
            with urllib.request.urlopen(req, timeout=2) as response:
                if response.status == 200:
                    return True
        except:
            pass
        
        # 或者尝试直接访问主页面
        try:
            req = urllib.request.Request(
                check_url,
                method='HEAD',
                headers={'User-Agent': 'Mozilla/5.0'}
            )
            with urllib.request.urlopen(req, timeout=2) as response:
                if response.status == 200:
                    return True
        except:
            pass
        
        time.sleep(0.5)
        print(".", end='', flush=True)
    
    print("")
    return False

def main():
    """主函数"""
    # 防止重复启动 - 检查是否已有实例在运行
    lock_file = os.path.expanduser('~/.weekly_report_generator.lock')
    if os.path.exists(lock_file):
        try:
            with open(lock_file, 'r') as f:
                old_pid = int(f.read().strip())
            # 检查进程是否还在运行
            os.kill(old_pid, 0)
            print("⚠️  周报生成器已经在运行！")
            print("🌐 请访问: http://localhost:8501")
            input("按回车键退出...")
            return
        except (OSError, ValueError):
            # 进程不存在，删除锁文件
            os.remove(lock_file)
    
    # 创建锁文件
    with open(lock_file, 'w') as f:
        f.write(str(os.getpid()))
    
    try:
        # 设置工作目录
        if hasattr(sys, '_MEIPASS'):
            os.chdir(sys._MEIPASS)
        else:
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
        
        print("=" * 50)
        print("🚀 周报生成器启动中...")
        print("=" * 50)
        
        # 检查端口是否被占用，寻找可用端口
        port = 8501
        max_port = 8510
        
        while port <= max_port:
            if check_port_available(port):
                break
            port += 1
        
        if port > max_port:
            print("❌ 无法找到可用端口 (8501-8510 都被占用)")
            input("按回车键退出...")
            return
        
        print(f"📡 使用端口: {port}")
        
        # 设置环境变量
        env = os.environ.copy()
        env['STREAMLIT_SERVER_HEADLESS'] = 'true'
        env['STREAMLIT_SERVER_PORT'] = str(port)
        env['STREAMLIT_SERVER_ADDRESS'] = '127.0.0.1'  # 使用 IP 而不是 localhost
        env['STREAMLIT_BROWSER_GATHERUSAGESTATS'] = 'false'
        env['STREAMLIT_SERVER_ENABLECORS'] = 'false'
        env['STREAMLIT_SERVER_ENABLEXSRFPROTECTION'] = 'false'
        
        # 启动 Streamlit
        try:
            process = subprocess.Popen(
                [sys.executable, '-m', 'streamlit', 'run', 'app.py',
                 f'--server.port={port}',
                 '--server.address=127.0.0.1',
                 '--browser.gatherUsageStats=false',
                 '--server.headless=true'],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
        except Exception as e:
            print(f"❌ 启动失败: {e}")
            input("按回车键退出...")
            return
        
        # 读取输出的线程
        def read_output():
            try:
                for line in process.stdout:
                    print(line, end='')
                    # 如果检测到错误，打印出来
                    if 'Error' in line or 'error' in line:
                        sys.stdout.flush()
            except:
                pass
        
        output_thread = threading.Thread(target=read_output, daemon=True)
        output_thread.start()
        
        # 等待服务真正启动
        url = f'http://localhost:{port}'
        
        if not wait_for_server(url, timeout=60):
            print("")
            print("❌ 服务启动超时，可能出现问题")
            print("请检查上面的错误信息")
            process.terminate()
            input("按回车键退出...")
            return
        
        print("")
        print(f"✅ 服务已启动！")
        
        # 尝试打开浏览器（只打开一次）
        print(f"🌐 正在打开浏览器: {url}")
        try:
            # 使用 Mac 的 open 命令（如果在 Mac 上）
            if sys.platform == 'darwin':
                subprocess.Popen(['open', url])
            else:
                webbrowser.open(url, new=2)  # new=2 表示在新标签页打开
        except Exception as e:
            print(f"⚠️ 无法自动打开浏览器，请手动访问: {url}")
        
        print("")
        print("=" * 50)
        print("✅ 周报生成器运行中！")
        print(f"🌐 访问地址: {url}")
        print("")
        print("⚠️  请不要关闭此窗口")
        print("🛑 关闭此窗口将停止服务")
        print("=" * 50)
        print("")
        
        # 处理退出信号
        def signal_handler(sig, frame):
            print("\n🛑 正在关闭服务...")
            process.terminate()
            try:
                process.wait(timeout=5)
            except:
                process.kill()
            print("✅ 服务已停止")
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # 等待进程结束
        try:
            process.wait()
        except KeyboardInterrupt:
            signal_handler(None, None)
    
    finally:
        # 清理锁文件
        if os.path.exists(lock_file):
            os.remove(lock_file)

if __name__ == '__main__':
    main()
